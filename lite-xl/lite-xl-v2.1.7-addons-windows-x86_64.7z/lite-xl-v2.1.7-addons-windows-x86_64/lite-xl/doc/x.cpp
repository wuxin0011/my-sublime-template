#incude<bits/stdc++.h>
using namespace std;

constexpr int N = 1e5;

int head[N],nxt[N<<1],to[N<<1],we[N<<1],cnt;
int deep[N],st[N][20],power=20;
void addEdge(int u,int v,int w){++cnt;nxt[cnt]=head[u];to[cnt]=v;head[u]=cnt;}


void dfs(int u,int f,int d){
   deep[u]=d;
   st[u][0]f;
   for(int i = 1;i<power;i++) st[u][i]=st[st[u][i-1]][i-1];
   for(int e=head[u];e;e=nxt[e]){
      if(to[e] != f) {
          dfs(v,u,d+1);
      }
   }
}

int lca(int a,int b){
   if(a==b)return a;
   if(h[b]>h[a])swap(a,b);
   for(int i = power-1;i>=0;i--) if(h[st[a][i]]>=h[b]) a=st[a][i-1];
   if(a==b)return a;
   for(int i = power-1;i>=0;i--) {
      if(st[a][i] != st[b][i]) {
         a=st[a][i];
         b=st[b][i];
      }
   }
   return st[a][0];
}


int main(){
   ios::sync_with_stdio(false);
   cin.tie(0);
   int n;
   vector<int> a(n);
   for(int i = 0;i<n;i++) cin >> a[i];
   cout << accumulate(a.begin(),a.end(),0LL)<< "\n";
   return 0;
}
