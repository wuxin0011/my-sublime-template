local function auto_pairs(char)
  local doc = core.active_view.doc
  if not doc then return end

  local pairs = {
      ["("] = ")",
      ["["] = "]",
      ["{"] = "}",
      ["\""] = "\"",
      ["'"] = "'"
  }
  local close_char = pairs[char]

  if close_char then
      -- 检查是否在字符串或注释中（可选）
      local syntax = doc:get_syntax()
      local line, col = doc:get_selection()
      local state = syntax:get_state(line, col)
      if state ~= "string" and state ~= "comment" then
          doc:insert(close_char)
          doc:move_to(-1)  -- 光标回退到括号内
      end
  end
end

-- 绑定到按键输入事件
command.add("core.docview", {
  ["auto-pairs:on-insert"] = function()
      local doc = core.active_view.doc
      if not doc then return end
      local text = doc:get_text(doc:get_selection())
      auto_pairs(text)
  end
})

-- 监听所有插入操作
keymap.add({ ["on_insert"] = "auto-pairs:on-insert" })