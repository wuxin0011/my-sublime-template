return {recents={[1]="D:\\desktop\\xite-temp"}, window={[1]=1177,[2]=614,[3]=20,[4]=83,["n"]=4}, window_mode="normal", previous_find={}, previous_replace={}}
