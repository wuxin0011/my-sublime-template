return {
  ["config"] = {
    ["code_font"] = {
      ["fonts"] = {
        [1] = {
          ["name"] = "Consolas Regular",
          ["path"] = "C:\\Windows\\Fonts\\consola.ttf"
        }
      },
      ["options"] = {
        ["antialiasing"] = "subpixel",
        ["bold"] = false,
        ["hinting"] = "slight",
        ["italic"] = false,
        ["size"] = 15,
        ["smoothing"] = false,
        ["strikethrough"] = false,
        ["underline"] = false
      }
    },
    ["custom_keybindings"] = {
      ["doc:delete-lines"] = {
        [1] = "shift+delete"
      }
    },
    ["disabled_plugins"] = {},
    ["enabled_plugins"] = {
      ["custom_caret"] = true,
      ["opacity"] = true,
      ["open_ext"] = true,
      ["projectsearch"] = true,
      ["quote"] = true,
      ["workspace"] = true
    },
    ["font"] = {
      ["fonts"] = {
        [1] = {
          ["name"] = "Fira Code Regular",
          ["path"] = "C:\\Users\\Administrator\\AppData\\Local\\Microsoft\\Windows\\Fonts\\FiraCode-Regular.ttf"
        }
      },
      ["options"] = {
        ["antialiasing"] = "subpixel",
        ["bold"] = false,
        ["hinting"] = "slight",
        ["italic"] = false,
        ["size"] = 15,
        ["smoothing"] = false,
        ["strikethrough"] = false,
        ["underline"] = false
      }
    },
    ["indent_size"] = 4,
    ["plugins"] = {
      ["autowrap"] = {
        ["enabled"] = true
      },
      ["custom_caret"] = {
        ["caret_color"] = {
          ["n"] = 4,
          [1] = 248,
          [2] = 248,
          [3] = 240,
          [4] = 255
        }
      },
      ["minimap"] = {
        ["caret_color"] = {
          [1] = 147,
          [2] = 221,
          [3] = 250,
          [4] = 255
        },
        ["selection_color"] = {
          [1] = 82,
          [2] = 82,
          [3] = 87,
          [4] = 255
        }
      }
    },
    ["theme"] = "vscode-dark"
  }
}
