return {recents={}, window={[1]=1219,[2]=614,[3]=136,[4]=77,["n"]=4}, window_mode="normal", previous_find={}, previous_replace={}}
