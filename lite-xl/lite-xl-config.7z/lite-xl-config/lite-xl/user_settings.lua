return {
  ["config"] = {
    ["code_font"] = {
      ["fonts"] = {
        [1] = {
          ["name"] = "Fira Code Medium",
          ["path"] = "C:\\Users\\Administrator\\AppData\\Local\\Microsoft\\Windows\\Fonts\\Deleted\\FIRACODE-MEDIUM-3.TTF"
        }
      },
      ["options"] = {
        ["antialiasing"] = "subpixel",
        ["bold"] = false,
        ["hinting"] = "slight",
        ["italic"] = false,
        ["size"] = 15,
        ["smoothing"] = false,
        ["strikethrough"] = false,
        ["underline"] = false
      }
    },
    ["custom_keybindings"] = {
      ["doc:delete-lines"] = {
        [1] = "shift+delete"
      }
    },
    ["enabled_plugins"] = {
      ["custom_caret"] = true
    },
    ["font"] = {
      ["fonts"] = {
        [1] = {
          ["name"] = "Fira Code Medium",
          ["path"] = "C:\\Users\\Administrator\\AppData\\Local\\Microsoft\\Windows\\Fonts\\Deleted\\FIRACODE-MEDIUM-3.TTF"
        }
      },
      ["options"] = {
        ["antialiasing"] = "subpixel",
        ["bold"] = false,
        ["hinting"] = "slight",
        ["italic"] = false,
        ["size"] = 15,
        ["smoothing"] = false,
        ["strikethrough"] = false,
        ["underline"] = false
      }
    },
    ["indent_size"] = 4,
    ["plugins"] = {
      ["autowrap"] = {
        ["enabled"] = true
      },
      ["custom_caret"] = {
        ["caret_color"] = {
          ["n"] = 4,
          [1] = 248,
          [2] = 248,
          [3] = 240,
          [4] = 255
        }
      },
      ["minimap"] = {
        ["caret_color"] = {
          [1] = 147,
          [2] = 221,
          [3] = 250,
          [4] = 255
        },
        ["selection_color"] = {
          [1] = 82,
          [2] = 82,
          [3] = 87,
          [4] = 255
        }
      }
    },
    ["theme"] = "monokai-pro-classic"
  }
}
